package zad2_e;

public class Main {

	public static void main(String[] args) {
		NaturalNumber n = new NaturalNumber(3);
		for(Integer i : n) {
			System.out.println(i);
		}
	}
}
