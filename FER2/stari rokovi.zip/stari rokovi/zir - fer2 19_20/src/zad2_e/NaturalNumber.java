package zad2_e;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

public class NaturalNumber implements Comparable<NaturalNumber>, Iterable<Integer> {
	
	Integer n; // može i int n;

	public NaturalNumber(Integer n) { // može i: int n
		super();
		Objects.requireNonNull(n); // ne treba ako je n int a ne Integer; ali oprostit ćemo i ako su zaboravili na ovo
		if(n<1) throw new NotNaturalNumberException(n);
		this.n = n;
	}
	
	public NaturalNumber(NaturalNumber other) {
		this(other.n); // ili izravno može popamtiti što treba
	}

	public NaturalNumber next() {
		return new NaturalNumber(n+1);
	}
	
	public Integer getValue() {
		return n;
	}
	
	@Override
	public String toString() {
		return Integer.toString(n);
	}
	
	@Override
	public int compareTo(NaturalNumber o) {
		return Integer.compare(o.n, this.n);
	}
	
	@Override
	public int hashCode() {
		return n.hashCode();
	}
	
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof NaturalNumber)) return false;
		NaturalNumber other = (NaturalNumber)obj;
		return this.n.equals(other.n); // ili this.n==other.n ako je tip int a ne Integer
	}

	@Override
	public Iterator<Integer> iterator() {
		return new MyIterator(n);
	}
	
	private static class MyIterator implements Iterator<Integer> {
		int nextValue;

		public MyIterator(int nextValue) {
			super();
			this.nextValue = nextValue;
		}
		
		@Override
		public boolean hasNext() {
			return nextValue >= 1;
		}
		
		@Override
		public Integer next() {
			if(!hasNext()) throw new NoSuchElementException();
			return nextValue--;
		}
	}
}
