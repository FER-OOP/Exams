package zad2_e;

public class NotNaturalNumberException extends RuntimeException {
	private int offendingValue;

	public NotNaturalNumberException(int offendingValue) {
		super();
		this.offendingValue = offendingValue;
	}
	
	public int getOffendingValue() {
		return offendingValue;
	}
}
