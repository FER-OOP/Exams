package zad2_a;

public class Main {

	public static void main(String[] args) {
		NaturalNumber n1 = new NaturalNumber(3);
		NaturalNumber n2 = new NaturalNumber(n1);
		NaturalNumber n3 = n2.next();
		Integer v = n2.getValue();
		System.out.println(v); // ispisuje 3
		System.out.println(n1); // ispisuje 3
		System.out.println(n3); // ispisuje 4
	}
}
