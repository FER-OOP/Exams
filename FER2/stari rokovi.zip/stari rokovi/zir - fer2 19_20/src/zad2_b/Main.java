package zad2_b;

public class Main {

	public static void main(String[] args) {
		NaturalNumber n1 = new NaturalNumber(3);
		try {
			NaturalNumber n2 = new NaturalNumber(-2);
		} catch(NotNaturalNumberException e) {
			int offendingValue = e.getOffendingValue();
			System.out.println(offendingValue + " nije prirodni broj.");
		}
	}
}
