package zad2_b;

public class NotNaturalNumberException extends RuntimeException {
	private int offendingValue;

	public NotNaturalNumberException(int offendingValue) {
		super();
		this.offendingValue = offendingValue;
	}
	
	public int getOffendingValue() {
		return offendingValue;
	}
}
