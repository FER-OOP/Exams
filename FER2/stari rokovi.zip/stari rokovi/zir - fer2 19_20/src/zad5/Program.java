package zad5;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.util.function.IntBinaryOperator;
import java.util.function.IntUnaryOperator;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

public class Program extends JFrame {

	public Program() {
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		initGUI();
		pack();
	}
	
	private void initGUI() {
		Container cp = getContentPane();
		
		JTextField tfFirst = new JTextField("0");
		JTextField tfSecond = new JTextField("0");
		JLabel result = new JLabel();
		
		JPanel central = new JPanel(new GridLayout(3, 2));
		central.add(new JLabel("Broj A: "));
		central.add(tfFirst);
		central.add(new JLabel("Broj B: "));
		central.add(tfSecond);
		central.add(new JLabel("Rezultat: "));
		central.add(result);

		cp.add(central, BorderLayout.CENTER);
		
		JPanel bottom = new JPanel(new GridLayout(1,0));
		JButton b1 = new JButton("A--");
		JButton b2 = new JButton("A++");
		JButton b3 = new JButton("B--");
		JButton b4 = new JButton("B++");
		JButton b5 = new JButton("Zbroji");

		bottom.add(b1);
		bottom.add(b2);
		bottom.add(b3);
		bottom.add(b4);
		bottom.add(b5);

		cp.add(bottom, BorderLayout.PAGE_END);

		b1.addActionListener(e->modify(tfFirst, b->b-1));
		b2.addActionListener(e->modify(tfFirst, b->b+1));
		b3.addActionListener(e->modify(tfSecond, b->b-1));
		b4.addActionListener(e->modify(tfSecond, b->b+1));
		b5.addActionListener(e->modify(tfFirst, tfSecond, result, (x,y)->x+y));
		
		initMenus();
	}
	
	private void initMenus() {
		JMenuBar mb = new JMenuBar();
		
		JMenu m = new JMenu("File");
		mb.add(m);
		
		JMenuItem mit = new JMenuItem("Exit");
		mit.addActionListener(l->dispose());
		m.add(mit);
		
		setJMenuBar(mb);
	}
	
	private void modify(JTextField tf, IntUnaryOperator oper) {
		String currentText = tf.getText();
		int currentValue = Integer.parseInt(currentText);
		int newValue = oper.applyAsInt(currentValue);
		tf.setText(Integer.toString(newValue));
	}

	private void modify(JTextField tf1, JTextField tf2, JLabel result, IntBinaryOperator oper) {
		int v1 = Integer.parseInt(tf1.getText());
		int v2 = Integer.parseInt(tf2.getText());
		int newValue = oper.applyAsInt(v1,v2);
		result.setText(Integer.toString(newValue));
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(()->{new Program().setVisible(true);});
	}
}
