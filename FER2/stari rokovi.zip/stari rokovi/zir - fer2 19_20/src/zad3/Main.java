package zad3;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		if(args.length != 1) {
			System.out.println("Očekujem jedan argument.");
			return;
		}
		
		Path root = Paths.get(args[0]);
		
		if(!Files.isDirectory(root)) {
			System.out.println("Direktorij ne postoji.");
			return;
		}

		Posao x = new Posao();
		try {
			Files.walkFileTree(root, x);
		} catch (IOException e) {
			System.out.println("Obilazak nije moguć.");
			return;
		}
		
		for(String u : x.getVisitedURLs()) { System.out.println(u); }
	}
	
	private static class Posao implements FileVisitor<Path> {
		private Path withMostURLs;
		private int countForWithMostURLs = 0;
		private Set<String> visitedURLs = new TreeSet<>();
		private int numberOfFiles;
		
		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
			if(!file.getFileName().toString().endsWith(".wt")) return FileVisitResult.CONTINUE;
			numberOfFiles++;
			List<String> lines = Files.readAllLines(file);
			int count = 0;
			for(String line : lines) {
				if(line.startsWith("url:")) {
					count++;
					String url = line.substring(4).trim();
					visitedURLs.add(url);
				}
			}
			if(countForWithMostURLs==0 || count > countForWithMostURLs) {
				countForWithMostURLs = count;
				withMostURLs = file;
			}
			return FileVisitResult.CONTINUE;
		}
		
		@Override
		public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
			return FileVisitResult.CONTINUE;
		}
		
		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
			return FileVisitResult.CONTINUE;
		}
		
		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
			return FileVisitResult.CONTINUE;
		}
		
		public int getNumberOfFiles() {
			return numberOfFiles;
		}
		
		public Set<String> getVisitedURLs() {
			return visitedURLs;
		}
		
		public Path getFileWithMostURLs() {
			return withMostURLs;
		}
	}
}
