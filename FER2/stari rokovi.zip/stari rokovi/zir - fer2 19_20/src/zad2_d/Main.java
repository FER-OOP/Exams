package zad2_d;

import java.util.HashSet;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		Set<NaturalNumber> set = new HashSet<>();
		set.add(new NaturalNumber(3));
		set.add(new NaturalNumber(3));
		set.add(new NaturalNumber(4));
		System.out.println(set.contains(new NaturalNumber(4))); // true
		System.out.println(set.size()); // size = 2
	}
}
