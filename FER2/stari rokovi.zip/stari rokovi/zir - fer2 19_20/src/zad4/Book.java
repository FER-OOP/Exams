package zad4;

import java.util.Set;

public class Book {
	private Set<String> authors;
	private Set<String> formats;
	private int publicationYear;
	private int numberOfPages;
	private String title;
	private Set<String> languages;
	public Set<String> getAuthors() {
		return authors;
	}
	public Set<String> getFormats() {
		return formats;
	}
	public int getPublicationYear() {
		return publicationYear;
	}
	public int getNumberOfPages() {
		return numberOfPages;
	}
	public String getTitle() {
		return title;
	}
	public Set<String> getLanguages() {
		return languages;
	}
	
	
}
