package zad4;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
		Comparator<Book> c1 = new Comparator<Book>() {
			@Override
			public int compare(Book o1, Book o2) {
				return Integer.compare(o1.getNumberOfPages(), o2.getNumberOfPages());
			}
		};
		
		Comparator<Book> c2 = (b1,b2) -> Integer.compare(b1.getAuthors().size(), b2.getAuthors().size());
		
		Comparator<Book> c3 = c1.reversed().thenComparing(c2);
		
		Collection<Book> col = new HashSet<>();
		col.stream().forEach(System.out::println);
		col.stream().forEach(b->System.out.println(b));

		Optional<Book> book = col.stream().sorted(c1).findFirst();
		
		col.stream().filter(b->b.getPublicationYear()>=2010).forEach(System.out::println);
		
		Set<String> titles = col.stream().map(b->b.getTitle()).collect(Collectors.toSet());
		Set<String> titles2 = col.stream().map(Book::getTitle).collect(Collectors.toSet());

		int ukupniBrojStranica = col.stream().mapToInt(Book::getNumberOfPages).sum();
		
		col.stream().flatMap(b->b.getLanguages().stream()).distinct().sorted().forEach(System.out::println);
	}
}
