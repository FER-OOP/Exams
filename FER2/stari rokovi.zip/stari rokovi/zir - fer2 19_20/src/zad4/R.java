package zad4;

import java.util.Comparator;

public class R implements Comparator<Book> {
	
	@Override
	public int compare(Book o1, Book o2) {
		return Integer.compare(o1.getPublicationYear(), o2.getPublicationYear());
	}

}
