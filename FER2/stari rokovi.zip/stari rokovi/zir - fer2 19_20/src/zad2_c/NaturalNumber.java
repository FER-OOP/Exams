package zad2_c;

import java.util.Objects;

public class NaturalNumber implements Comparable<NaturalNumber> {
	
	Integer n; // može i int n;

	public NaturalNumber(Integer n) { // može i: int n
		super();
		Objects.requireNonNull(n); // ne treba ako je n int a ne Integer; ali oprostit ćemo i ako su zaboravili na ovo
		if(n<1) throw new NotNaturalNumberException(n);
		this.n = n;
	}
	
	public NaturalNumber(NaturalNumber other) {
		this(other.n); // ili izravno može popamtiti što treba
	}

	public NaturalNumber next() {
		return new NaturalNumber(n+1);
	}
	
	public Integer getValue() {
		return n;
	}
	
	@Override
	public String toString() {
		return Integer.toString(n);
	}
	
	@Override
	public int compareTo(NaturalNumber o) {
		return Integer.compare(o.n, this.n);
	}
}
