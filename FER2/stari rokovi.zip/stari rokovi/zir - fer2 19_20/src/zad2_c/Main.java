package zad2_c;

import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		NaturalNumber[] arr = new NaturalNumber[] {
				new NaturalNumber(3),
				new NaturalNumber(1),
				new NaturalNumber(5),
				new NaturalNumber(2),
				new NaturalNumber(7),
		};
		Arrays.sort(arr);
		for(NaturalNumber n : arr) System.out.println(n);
	}
}
