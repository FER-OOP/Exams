package zad1;

public interface NumberProducer {
	int getNumber();
}
