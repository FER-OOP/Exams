package zi;

public class Author {

	private String firstName;
	private String lastName;
	private String email;
	private String institution;
	
	public Author(String firstName, String lastName, String email, String institution) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.institution = institution;
	}
	
	// plus getteri, equals, hashcode...
}
