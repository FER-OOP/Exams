package zi.zad01;

import java.nio.file.Path;

import zi.ScientificPaper;

public class LoaderUtil {

	public static ScientificPaper load(Path file) {
		// Ne treba implementirati u okviru ispita...
		return null;
	}

}
